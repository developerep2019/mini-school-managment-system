const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('tetulia_pilot', 'user__tetulia_pilot', 'mrPass@tetulia@pilot', {
    host: 'localhost',
    dialect: 'mysql',

});
module.exports = sequelize;